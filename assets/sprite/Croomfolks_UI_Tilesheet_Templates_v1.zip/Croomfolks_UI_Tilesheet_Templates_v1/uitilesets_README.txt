
Hello! Thank you for downloading my asset pack.

This file includes two simple 32x tilesets, created to allow developers to focus on painting their UI's visuals without worrying about proper tiling of the blocks - my aim is to make this tileset include all basic shapes I can think of, from diagonals and multi-tile curved edges to 'windows' and other inner gaps. These tiles can be remixed to create all sorts of connecting textures besides UI (I have recently used them as a base to make a topdown castle battlements tileset for a personal project).

This includes a 32x tileset for the background/panels, and a separate tileset for buttons/item slots. This second tileset is smaller,
with a 16x area not counting borders, but centralized on 32x tiles for easier use in combination with the other one.

Besides the ready to use tilesets, a sourcefile is included where I tested all of the combinations and built out from a set of initial pieces. You can look at it for usage instructions as well as inspiration. Notice any missing shapes or impossible combinations? Let me know and I'll expand the pack :) Currently I know of some shapes not covered by the button tileset, and I'll work to expand it as soon as possible, so stay tuned!

This file was created as part of the Howlfire Co-Jam Zero - https://itch.io/jam/howl-fire-co-jam

=-=-=-LICENSE-=-=-=


These assets, including the exported PNGs and the source file, are licensed as CC-BY-SA 4.0 (Creative Commons Attribution ShareAlike 4.0 International).

This means you are allowed to use and modify them for any project, commercial or not, as long as you follow the instructions of that license:

https://creativecommons.org/licenses/by-sa/4.0/

The terms are:

1. You must give me credit as the author, and add a link to the place where you got this pack  (either my itch.io page or OpenGameArt page are fine)

2. You must also mention the license of the items you are using, and link to the license (the link above)

3. You must mention if the assets as presented in your project are my originals or further modified by you.

4. If you remix, transform, or build upon the material, you must distribute your contributions under the same license as the original.

Following these instructions, you are good to go!

The only exception to the freedom that CC-BY-SA grants you is commercial use of this material with false suggestions to your buyers that they are receiving
something valuable for its scarcity and uniqueness (such as NFTs).

For more information on the sale of openly-licensed assets as NFTs (and the charges of Fraud that are very likely to come with that), please see the links below.

They were written for a specific website, but the principle of implying value from a scarcity that is not present on this asset pack remains the same across the Internet:

https://opengameart.org/content/warning-taking-art-from-opengameartorg-to-be-sold-as-nfts-you-may-be-committing-fraud

https://opengameart.org/content/note-of-caution-to-nft-purchasers-or-those-interested-in-trading-nfts

Besides, NFTs are dead anyways. LMAO

-----

UI Tileset Templates - by Croomfolk

https://croomfolk.carrd.co