import Scrollable, {defaultOptions} from './Scrollable';

export default Scrollable;
export {defaultOptions};
