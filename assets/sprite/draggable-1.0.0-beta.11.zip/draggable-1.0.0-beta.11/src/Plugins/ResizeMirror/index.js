import ResizeMirror, {defaultOptions} from './ResizeMirror';

export default ResizeMirror;
export {defaultOptions};
