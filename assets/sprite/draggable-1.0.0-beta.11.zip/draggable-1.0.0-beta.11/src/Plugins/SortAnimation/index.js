import SortAnimation, {defaultOptions} from './SortAnimation';

export default SortAnimation;
export {defaultOptions};
