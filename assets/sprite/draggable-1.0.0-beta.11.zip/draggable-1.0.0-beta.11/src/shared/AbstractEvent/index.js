import AbstractEvent from './AbstractEvent';

export default AbstractEvent;
