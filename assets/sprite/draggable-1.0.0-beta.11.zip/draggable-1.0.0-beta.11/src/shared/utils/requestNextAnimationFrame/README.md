## requestNextAnimationFrame

Utility method that requests the next animation frame, which is achieved by double wrapping animation frames.
